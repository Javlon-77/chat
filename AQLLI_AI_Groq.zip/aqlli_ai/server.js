require('dotenv').config();
const express = require('express');
const path = require('path');
const OpenAI = require('openai');
const app = express();
app.use(express.json({limit:'1mb'}));
app.use(express.static(__dirname));
const key = (process.env.GROQ_API_KEY || '').trim();
const client = key ? new OpenAI({apiKey:key,baseURL:'https://api.groq.com/openai/v1'}) : null;
app.get('/api/health',(_req,res)=>res.json({ok:true,configured:!!client}));
app.post('/api/chat',async(req,res)=>{
 try {
  if(!client)return res.status(503).json({error:'Groq API kaliti sozlanmagan. .env fayliga GROQ_API_KEY kiriting.'});
  const msgs=Array.isArray(req.body?.messages)?req.body.messages:[];
  const messages=msgs.filter(m=>['user','assistant'].includes(m.role)&&typeof m.content==='string').slice(-30).map(m=>({role:m.role,content:m.content.slice(0,12000)}));
  if(!messages.length||messages[messages.length-1].role!=='user')return res.status(400).json({error:'Avval savolingizni yozing.'});
  const result=await client.chat.completions.create({model:process.env.GROQ_MODEL||'llama-3.3-70b-versatile',messages:[{role:'system',content:'Sen AQLLI AI nomli foydali yordamchisan. Foydalanuvchiga o‘zbek tilida aniq, muloyim va tushunarli javob ber. Boshqa til so‘ralsa o‘sha tilda javob ber. Kerak bo‘lsa misollar va kod keltir.'},...messages],temperature:0.7,max_tokens:2048});
  res.json({answer:result.choices?.[0]?.message?.content||'Kechirasiz, javob yaratilmadi.'});
 } catch(err){console.error('Groq error:',err?.message||err);let msg=err?.status===401?'API kaliti noto‘g‘ri yoki yaroqsiz.':err?.status===429?'So‘rov limiti tugagan yoki juda ko‘p so‘rov yuborildi.':'Groq xizmatiga ulanib bo‘lmadi. API sozlamalarini tekshiring.';res.status(500).json({error:msg});}
});
const port=Number(process.env.PORT||3000);app.listen(port,()=>console.log(`AQLLI AI: http://localhost:${port}`));
