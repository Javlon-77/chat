# AQLLI AI — Groq bilan ishlaydigan savol-javob sayti

## Ishga tushirish (Windows)
1. Node.js o'rnating: https://nodejs.org/
2. Ushbu papkada CMD/Terminal oching.
3. `npm install` buyrug'ini bajaring.
4. `.env.example` faylidan nusxa oling va nusxani `.env` deb nomlang.
5. `.env` faylida `GROQ_API_KEY=` dan keyin Groq kalitingizni yozing.
6. `npm start` buyrug'ini bajaring.
7. Brauzerda http://localhost:3000 ni oching.

API kalitini `index.html` ichiga yoki GitHub repository'ga joylamang. `.env` fayli `.gitignore` orqali GitHub'dan chiqarilgan.

## Hosting
GitHub Pages faqat statik frontendni ishlatadi; `server.js` uchun Node.js backend hosting (masalan, Render yoki Railway) kerak. Hosting sozlamalarida `GROQ_API_KEY` va kerak bo'lsa `GROQ_MODEL` environment variable qilib kiriting.
